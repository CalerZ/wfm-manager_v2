package com.ruoyi.wfm.domain;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.ruoyi.common.annotation.Excel;
import com.ruoyi.common.core.domain.BaseEntity;

/**
 * 【请填写功能名称】对象 wfm_list_favorite
 * 
 * @author ruoyi
 * @date 2021-10-22
 */
public class WfmListFavorite extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /** $column.columnComment */
    private Long id;

    /** wfm_id */
    @Excel(name = "wfm_id")
    private String wfmName;

    /** wfm_id */
    @Excel(name = "wfm_id")
    private Long wfmId;

    /** user_id */
    @Excel(name = "user_id")
    private Long userId;

    public void setId(Long id) 
    {
        this.id = id;
    }

    public Long getId() 
    {
        return id;
    }
    public void setWfmName(String wfmName) 
    {
        this.wfmName = wfmName;
    }

    public String getWfmName() 
    {
        return wfmName;
    }
    public void setWfmId(Long wfmId) 
    {
        this.wfmId = wfmId;
    }

    public Long getWfmId() 
    {
        return wfmId;
    }
    public void setUserId(Long userId) 
    {
        this.userId = userId;
    }

    public Long getUserId() 
    {
        return userId;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("id", getId())
            .append("wfmName", getWfmName())
            .append("wfmId", getWfmId())
            .append("userId", getUserId())
            .toString();
    }
}
