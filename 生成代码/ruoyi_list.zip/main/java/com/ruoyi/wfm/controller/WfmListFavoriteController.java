package com.ruoyi.wfm.controller;

import java.util.List;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.enums.BusinessType;
import com.ruoyi.wfm.domain.WfmListFavorite;
import com.ruoyi.wfm.service.IWfmListFavoriteService;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.common.core.page.TableDataInfo;

/**
 * 【请填写功能名称】Controller
 * 
 * @author ruoyi
 * @date 2021-10-22
 */
@Controller
@RequestMapping("/wfm/favorite")
public class WfmListFavoriteController extends BaseController
{
    private String prefix = "wfm/favorite";

    @Autowired
    private IWfmListFavoriteService wfmListFavoriteService;

    @RequiresPermissions("wfm:favorite:view")
    @GetMapping()
    public String favorite()
    {
        return prefix + "/favorite";
    }

    /**
     * 查询【请填写功能名称】列表
     */
    @RequiresPermissions("wfm:favorite:list")
    @PostMapping("/list")
    @ResponseBody
    public TableDataInfo list(WfmListFavorite wfmListFavorite)
    {
        startPage();
        List<WfmListFavorite> list = wfmListFavoriteService.selectWfmListFavoriteList(wfmListFavorite);
        return getDataTable(list);
    }

    /**
     * 导出【请填写功能名称】列表
     */
    @RequiresPermissions("wfm:favorite:export")
    @Log(title = "【请填写功能名称】", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    @ResponseBody
    public AjaxResult export(WfmListFavorite wfmListFavorite)
    {
        List<WfmListFavorite> list = wfmListFavoriteService.selectWfmListFavoriteList(wfmListFavorite);
        ExcelUtil<WfmListFavorite> util = new ExcelUtil<WfmListFavorite>(WfmListFavorite.class);
        return util.exportExcel(list, "【请填写功能名称】数据");
    }

    /**
     * 新增【请填写功能名称】
     */
    @GetMapping("/add")
    public String add()
    {
        return prefix + "/add";
    }

    /**
     * 新增保存【请填写功能名称】
     */
    @RequiresPermissions("wfm:favorite:add")
    @Log(title = "【请填写功能名称】", businessType = BusinessType.INSERT)
    @PostMapping("/add")
    @ResponseBody
    public AjaxResult addSave(WfmListFavorite wfmListFavorite)
    {
        return toAjax(wfmListFavoriteService.insertWfmListFavorite(wfmListFavorite));
    }

    /**
     * 修改【请填写功能名称】
     */
    @GetMapping("/edit/{id}")
    public String edit(@PathVariable("id") Long id, ModelMap mmap)
    {
        WfmListFavorite wfmListFavorite = wfmListFavoriteService.selectWfmListFavoriteById(id);
        mmap.put("wfmListFavorite", wfmListFavorite);
        return prefix + "/edit";
    }

    /**
     * 修改保存【请填写功能名称】
     */
    @RequiresPermissions("wfm:favorite:edit")
    @Log(title = "【请填写功能名称】", businessType = BusinessType.UPDATE)
    @PostMapping("/edit")
    @ResponseBody
    public AjaxResult editSave(WfmListFavorite wfmListFavorite)
    {
        return toAjax(wfmListFavoriteService.updateWfmListFavorite(wfmListFavorite));
    }

    /**
     * 删除【请填写功能名称】
     */
    @RequiresPermissions("wfm:favorite:remove")
    @Log(title = "【请填写功能名称】", businessType = BusinessType.DELETE)
    @PostMapping( "/remove")
    @ResponseBody
    public AjaxResult remove(String ids)
    {
        return toAjax(wfmListFavoriteService.deleteWfmListFavoriteByIds(ids));
    }
}
