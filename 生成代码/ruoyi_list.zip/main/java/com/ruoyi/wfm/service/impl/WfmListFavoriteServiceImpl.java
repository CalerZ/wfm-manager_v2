package com.ruoyi.wfm.service.impl;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ruoyi.wfm.mapper.WfmListFavoriteMapper;
import com.ruoyi.wfm.domain.WfmListFavorite;
import com.ruoyi.wfm.service.IWfmListFavoriteService;
import com.ruoyi.common.core.text.Convert;

/**
 * 【请填写功能名称】Service业务层处理
 * 
 * @author ruoyi
 * @date 2021-10-22
 */
@Service
public class WfmListFavoriteServiceImpl implements IWfmListFavoriteService 
{
    @Autowired
    private WfmListFavoriteMapper wfmListFavoriteMapper;

    /**
     * 查询【请填写功能名称】
     * 
     * @param id 【请填写功能名称】主键
     * @return 【请填写功能名称】
     */
    @Override
    public WfmListFavorite selectWfmListFavoriteById(Long id)
    {
        return wfmListFavoriteMapper.selectWfmListFavoriteById(id);
    }

    /**
     * 查询【请填写功能名称】列表
     * 
     * @param wfmListFavorite 【请填写功能名称】
     * @return 【请填写功能名称】
     */
    @Override
    public List<WfmListFavorite> selectWfmListFavoriteList(WfmListFavorite wfmListFavorite)
    {
        return wfmListFavoriteMapper.selectWfmListFavoriteList(wfmListFavorite);
    }

    /**
     * 新增【请填写功能名称】
     * 
     * @param wfmListFavorite 【请填写功能名称】
     * @return 结果
     */
    @Override
    public int insertWfmListFavorite(WfmListFavorite wfmListFavorite)
    {
        return wfmListFavoriteMapper.insertWfmListFavorite(wfmListFavorite);
    }

    /**
     * 修改【请填写功能名称】
     * 
     * @param wfmListFavorite 【请填写功能名称】
     * @return 结果
     */
    @Override
    public int updateWfmListFavorite(WfmListFavorite wfmListFavorite)
    {
        return wfmListFavoriteMapper.updateWfmListFavorite(wfmListFavorite);
    }

    /**
     * 批量删除【请填写功能名称】
     * 
     * @param ids 需要删除的【请填写功能名称】主键
     * @return 结果
     */
    @Override
    public int deleteWfmListFavoriteByIds(String ids)
    {
        return wfmListFavoriteMapper.deleteWfmListFavoriteByIds(Convert.toStrArray(ids));
    }

    /**
     * 删除【请填写功能名称】信息
     * 
     * @param id 【请填写功能名称】主键
     * @return 结果
     */
    @Override
    public int deleteWfmListFavoriteById(Long id)
    {
        return wfmListFavoriteMapper.deleteWfmListFavoriteById(id);
    }
}
