package com.ruoyi.wfm.mapper;

import java.util.List;
import com.ruoyi.wfm.domain.WfmListFavorite;

/**
 * 【请填写功能名称】Mapper接口
 * 
 * @author ruoyi
 * @date 2021-10-22
 */
public interface WfmListFavoriteMapper 
{
    /**
     * 查询【请填写功能名称】
     * 
     * @param id 【请填写功能名称】主键
     * @return 【请填写功能名称】
     */
    public WfmListFavorite selectWfmListFavoriteById(Long id);

    /**
     * 查询【请填写功能名称】列表
     * 
     * @param wfmListFavorite 【请填写功能名称】
     * @return 【请填写功能名称】集合
     */
    public List<WfmListFavorite> selectWfmListFavoriteList(WfmListFavorite wfmListFavorite);

    /**
     * 新增【请填写功能名称】
     * 
     * @param wfmListFavorite 【请填写功能名称】
     * @return 结果
     */
    public int insertWfmListFavorite(WfmListFavorite wfmListFavorite);

    /**
     * 修改【请填写功能名称】
     * 
     * @param wfmListFavorite 【请填写功能名称】
     * @return 结果
     */
    public int updateWfmListFavorite(WfmListFavorite wfmListFavorite);

    /**
     * 删除【请填写功能名称】
     * 
     * @param id 【请填写功能名称】主键
     * @return 结果
     */
    public int deleteWfmListFavoriteById(Long id);

    /**
     * 批量删除【请填写功能名称】
     * 
     * @param ids 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteWfmListFavoriteByIds(String[] ids);
}
