-- 菜单 SQL
insert into sys_menu (menu_name, parent_id, order_num, url, menu_type, visible, perms, icon, create_by, create_time, update_by, update_time, remark)
values('wfm_btn_config', '3', '1', '/system/config', 'C', '0', 'system:config:view', '#', 'admin', sysdate(), '', null, 'wfm_btn_config菜单');

-- 按钮父菜单ID
SELECT @parentId := LAST_INSERT_ID();

-- 按钮 SQL
insert into sys_menu (menu_name, parent_id, order_num, url, menu_type, visible, perms, icon, create_by, create_time, update_by, update_time, remark)
values('wfm_btn_config查询', @parentId, '1',  '#',  'F', '0', 'system:config:list',         '#', 'admin', sysdate(), '', null, '');

insert into sys_menu (menu_name, parent_id, order_num, url, menu_type, visible, perms, icon, create_by, create_time, update_by, update_time, remark)
values('wfm_btn_config新增', @parentId, '2',  '#',  'F', '0', 'system:config:add',          '#', 'admin', sysdate(), '', null, '');

insert into sys_menu (menu_name, parent_id, order_num, url, menu_type, visible, perms, icon, create_by, create_time, update_by, update_time, remark)
values('wfm_btn_config修改', @parentId, '3',  '#',  'F', '0', 'system:config:edit',         '#', 'admin', sysdate(), '', null, '');

insert into sys_menu (menu_name, parent_id, order_num, url, menu_type, visible, perms, icon, create_by, create_time, update_by, update_time, remark)
values('wfm_btn_config删除', @parentId, '4',  '#',  'F', '0', 'system:config:remove',       '#', 'admin', sysdate(), '', null, '');

insert into sys_menu (menu_name, parent_id, order_num, url, menu_type, visible, perms, icon, create_by, create_time, update_by, update_time, remark)
values('wfm_btn_config导出', @parentId, '5',  '#',  'F', '0', 'system:config:export',       '#', 'admin', sysdate(), '', null, '');
