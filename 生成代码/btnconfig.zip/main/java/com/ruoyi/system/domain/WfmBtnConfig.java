package com.ruoyi.system.domain;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.ruoyi.common.annotation.Excel;
import com.ruoyi.common.core.domain.BaseEntity;

/**
 * wfm_btn_config对象 wfm_btn_config
 * 
 * @author ruoyi
 * @date 2021-10-21
 */
public class WfmBtnConfig extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /** $column.columnComment */
    private Long id;

    /** name */
    @Excel(name = "name")
    private String name;

    /** type(1:jenkins/2:command) */
    @Excel(name = "type(1:jenkins/2:command)")
    private String type;

    /** url */
    @Excel(name = "url")
    private String url;

    /** job_name */
    @Excel(name = "job_name")
    private String jobName;

    /** token_type */
    @Excel(name = "token_type")
    private String tokenType;

    /** jenkins_param */
    @Excel(name = "jenkins_param")
    private String jenkinsParam;

    /** cmd_param */
    @Excel(name = "cmd_param")
    private String cmdParam;

    public void setId(Long id) 
    {
        this.id = id;
    }

    public Long getId() 
    {
        return id;
    }
    public void setName(String name) 
    {
        this.name = name;
    }

    public String getName() 
    {
        return name;
    }
    public void setType(String type) 
    {
        this.type = type;
    }

    public String getType() 
    {
        return type;
    }
    public void setUrl(String url) 
    {
        this.url = url;
    }

    public String getUrl() 
    {
        return url;
    }
    public void setJobName(String jobName) 
    {
        this.jobName = jobName;
    }

    public String getJobName() 
    {
        return jobName;
    }
    public void setTokenType(String tokenType) 
    {
        this.tokenType = tokenType;
    }

    public String getTokenType() 
    {
        return tokenType;
    }
    public void setJenkinsParam(String jenkinsParam) 
    {
        this.jenkinsParam = jenkinsParam;
    }

    public String getJenkinsParam() 
    {
        return jenkinsParam;
    }
    public void setCmdParam(String cmdParam) 
    {
        this.cmdParam = cmdParam;
    }

    public String getCmdParam() 
    {
        return cmdParam;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("id", getId())
            .append("name", getName())
            .append("type", getType())
            .append("url", getUrl())
            .append("jobName", getJobName())
            .append("tokenType", getTokenType())
            .append("jenkinsParam", getJenkinsParam())
            .append("cmdParam", getCmdParam())
            .append("updateTime", getUpdateTime())
            .toString();
    }
}
